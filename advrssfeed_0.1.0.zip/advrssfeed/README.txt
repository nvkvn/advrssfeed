moodle-block_advrssfeed
======================

#Advanced RSS Feed block - 0.1.0

###This block display items of RSS Feed on the front page.
- The release version for Moodle 2.5
- You can change the layout of this block with some options.

**Installation:**
Download and install the "Advanced RSS Feed" 

**Copyright:**
- ScrumLab (khoanv@fpt.aptech.ac.vn)
**Credit:**
	+ Hien Chu Van - hiencv_b01273@fpt.aptech.ac.vn
	+ Huy Le Xuan - huylx_b01374@fpt.aptech.ac.vn
	+ Linh Le Viet - linhlvgc00638@fpt.edu.vn
	+ Phuong Dang Phuong - phuongdp_b01302@fpt.aptech.ac.vn
	
